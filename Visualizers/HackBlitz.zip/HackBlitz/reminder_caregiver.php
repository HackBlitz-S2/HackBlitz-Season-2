<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caregiver Home - MedGuard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://smtpjs.com/v3/smtp.js"></script>
</head>
<body class="bg-gray-100 min-h-screen p-4">

    <!-- Navbar -->
    <nav class="bg-green-600 p-4 text-white flex justify-between items-center rounded-lg">
        <h1 class="text-xl font-bold">MedGuard - Caregiver Dashboard</h1>
        <button onclick="logout()" class="bg-red-500 px-4 py-2 rounded hover:bg-red-700 transition">Logout</button>
    </nav>

    <!-- Digital Clock -->
    <div class="text-right text-lg font-semibold text-gray-700 mt-2">
        ⏰ <span id="clock">Loading...</span>
    </div>

    <!-- Main Content -->
    <div class="max-w-4xl mx-auto mt-6">
        
        <!-- Welcome Card -->
        <div class="bg-white p-6 rounded-lg shadow-lg mb-6">
            <h2 class="text-2xl font-bold text-green-600">Welcome, Caregiver!</h2>
            <p class="text-gray-700 mt-2">Monitor and assist your assigned patients efficiently.</p>
        </div>

        <!-- Prescription Form -->
        <div class="bg-white p-6 rounded-lg shadow-lg mb-6">
            <h3 class="text-xl font-semibold text-green-600">Add Prescription</h3>
            <form id="prescriptionForm" class="mt-4">
                <input id="medicineName" type="text" placeholder="Medicine Name" required class="w-full px-4 py-2 mb-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500">
                <input id="medTime" type="time" required class="w-full px-4 py-2 mb-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500">
                <button type="submit" class="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition">Add Prescription</button>
            </form>
        </div>

        <!-- Medication Schedule -->
        <div class="bg-white p-6 rounded-lg shadow-lg mb-6">
            <h3 class="text-xl font-semibold text-green-600">Upcoming Medications</h3>
            <ul id="medSchedule" class="mt-4 space-y-2">
                <li class="bg-gray-100 p-4 rounded">No prescriptions added yet.</li>
            </ul>
        </div>
    </div>

    <script>
        function logout() {
            localStorage.clear();
            sessionStorage.clear();
            window.location.href = "index.html"; // Redirect to first page
        }

        let medications = {}; // Stores patient data

        function updateClock() {
            const now = new Date();
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');
            document.getElementById("clock").textContent = ${hours}:${minutes}:${seconds};

            checkReminders(); // Check reminders every second
        }

        setInterval(updateClock, 1000);

        function updateMedicationList() {
            const medList = document.getElementById("medSchedule");
            medList.innerHTML = "";

            if (Object.keys(medications).length === 0) {
                medList.innerHTML = <li class="bg-gray-100 p-4 rounded">No prescriptions added yet.</li>;
                return;
            }

            Object.entries(medications).forEach(([patient, details]) => {
                let patientCard = `
                    <li class="bg-gray-100 p-4 rounded">
                        <strong class="text-green-700">${patient}</strong>
                        <ul class="mt-2 space-y-2">
                            ${details.medicines.map((med, index) => `
                                <li class="bg-gray-200 p-3 rounded flex justify-between">
                                    ${med.medicine} at ${med.time}
                                    <div class="flex gap-2">
                                        <button onclick="editPrescription('${patient}', ${index})" class="text-blue-500 text-lg hover:text-blue-700">
                                            ✎
                                        </button>
                                        <button onclick="deletePrescription('${patient}', ${index})" class="text-red-500 text-lg hover:text-red-700">
                                            🗑
                                        </button>
                                    </div>
                                </li>
                            `).join("")}
                        </ul>
                    </li>
                `;
                medList.innerHTML += patientCard;
            });
        }

        document.getElementById("prescriptionForm").addEventListener("submit", function(event) {
            event.preventDefault();

            const patientName = document.getElementById("patientName").value;
            const patientEmail = document.getElementById("patientEmail").value;
            const medicineName = document.getElementById("medicineName").value;
            const medTime = document.getElementById("medTime").value;

            if (!medications[patientName]) {
                medications[patientName] = { email: patientEmail, medicines: [] };
            }

            medications[patientName].medicines.push({ medicine: medicineName, time: medTime });

            updateMedicationList();
            this.reset();
        });

        function checkReminders() {
            const now = new Date();
            const currentTime = ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')};

            Object.entries(medications).forEach(([patient, details]) => {
                details.medicines.forEach(med => {
                    if (med.time === currentTime) {
                        sendEmailReminder(details.email, med.medicine);
                    }
                });
            });
        }

        updateMedicationList();
    </script>

</body>
</html>