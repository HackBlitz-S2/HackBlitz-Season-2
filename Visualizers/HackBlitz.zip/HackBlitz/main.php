<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedGuard Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        function updateFormAction() {
            const roleSelect = document.getElementById('role');
            const form = document.getElementById('loginForm');
            if (roleSelect.value === 'patient') {
                form.action = 'connect.php'; // Change to the appropriate action for patients
            } else if (roleSelect.value === 'caregiver') {
                form.action = 'caregiver.php'; // Change to the appropriate action for caregivers
            }
        }
    </script>
</head>
<body class="bg-green-100 flex items-center justify-center min-h-screen p-4">
    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <h2 class="text-2xl font-bold text-green-600 text-center mb-6">MedGuard Login</h2>

        <form id="loginForm" method="GET" action="connect.php">
            <div class="mb-4">
                <label for="email" class="block text-gray-700 font-medium mb-2">Email:</label>
                <input id="email" type="email" placeholder="Enter your email" name="mail" required 
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
            </div>

            <div class="mb-4">
                <label for="password" class="block text-gray-700 font-medium mb-2">Password:</label>
                <input id="password" type="password" placeholder="Enter your password" name="password" required 
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
            </div>

            <!-- Role Selection -->
            <div class="mb-6">
                <label class="block text-gray-700 font-medium mb-2">Login as:</label>
                <select id="role" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500" onchange="updateFormAction()">
                    <option value="patient">Patient</option>
                    <option value="caregiver">Caregiver</option>
                </select>
            </div>

            <input type="submit" value="Submit" name="submit"
            class="w-full bg-green-600 text-white font-semibold py-2 rounded-lg 
                hover:bg-green-700 transition-all duration-300 ease-in-out 
                focus:outline-none focus:ring-4 focus:ring-green-400 cursor-pointer">

            <!-- Create Account Link -->
            <div class="mt-4 text-center">
                <p class="text-gray-600">Don't have an account? <a href="create_account.php" class="text-green-600 hover:underline">Create an Account</a></p>
            </div>
        </form>
    </div>
</body>
</html>