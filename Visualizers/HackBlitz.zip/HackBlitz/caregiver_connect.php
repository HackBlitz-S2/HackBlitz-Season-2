<?php
    $name=$_GET['name'];
    $email=$_GET['email'];
    $age=$_GET['age'];
    $gender=$_GET['gender'];
    $relation=$_GET['relation'];
    $p_mail=$_GET['p_mail'];

    $server="localhost";
    $username="root";
    $passward="";
    $database="medguard";
    $db=mysqli_connect($server,$username,$passward,$database);
    if($db)
    {
        header('location:reminder_caregiver.php');
    }
    else{
        echo "Connect not established";
    } 
    $sql="INSERT INTO `caregiver`(`name`, `email`, `age`, `gender`, `relation`, `p_mail`) VALUES ('$name','$email','$age','$gender','$relation','$p_mail')";
    mysqli_query($db,$sql);

    $sql="select * from login";
    $result=mysqli_query($db,$sql);
?>