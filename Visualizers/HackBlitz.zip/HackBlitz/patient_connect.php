<?php
    $name=$_GET['name'];
    $age=$_GET['age'];
    $gender=$_GET['gender'];
    $disease=$_GET['disease'];

    $server="localhost";
    $username="root";
    $passward="";
    $database="medguard";
    $db=mysqli_connect($server,$username,$passward,$database);
    if($db)
    {
        header('location:reminder_patient.php');
    }
    else{
        echo "Connect not established";
    } 
    $sql="INSERT INTO `patient`(`name`, `age`, `gender`, `disease`) VALUES ('$name','$age','$gender','$disease')";
    mysqli_query($db,$sql);

    $sql="select * from login";
    $result=mysqli_query($db,$sql);
?>