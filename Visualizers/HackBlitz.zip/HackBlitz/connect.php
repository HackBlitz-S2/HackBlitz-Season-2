<?php
    $mail=$_GET['mail'];
    $password=$_GET['password'];

    $server="localhost";
    $username="root";
    $passward="";
    $database="medguard";
    $db=mysqli_connect($server,$username,$passward,$database);
    if($db)
    {
        header('location:patient.php');
    }
    else{
        echo "Connect not established";
    } 
    $sql="INSERT INTO `login`(`mail`, `password`) VALUES ('$mail','$password')";
    mysqli_query($db,$sql);

    $sql="select * from login";
    $result=mysqli_query($db,$sql);
    while($row=$result->fetch_assoc()){
        echo "$row[mail]<br>";
        echo "$row[password]<br>";
        echo "<br><br>";
    }
?>