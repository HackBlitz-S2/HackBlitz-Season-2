<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caretaker Login</title>
    <style>
        /* Reset Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        /* Green background */
        body {
            background-image: url('https://i.pinimg.com/736x/bb/87/b7/bb87b743b9ed1dc1516a08955fe51842.jpg');

            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Form container */
        .container {
            background-color: rgb(202, 251, 234);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 350px;
            text-align: center;
        }

        /* Form title */
        h2 {
            font-size: 22px;
            font-weight: bold;
            color: #1a3b4c;
            margin-bottom: 5px;
        }

        /* Subtext */
        .subtext {
            font-size: 14px;
            color: #6b7b8c;
            margin-bottom: 20px;
        }

        /* Labels */
        label {
            font-size: 14px;
            font-weight: 600;
            display: block;
            text-align: left;
            margin: 10px 0 5px;
        }

        /* Input fields */
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #d1d5db;
            border-radius: 5px;
            font-size: 14px;
            background-color: #f8f9fa;
        }

        /* Error message */
        .error {
            color: red;
            font-size: 12px;
            text-align: left;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>CareTaker Login</h2>
        <p class="subtext">Please enter your information to continue</p>
        <form id="caretakerForm" method="GET" action="caregiver_connect.php" >
            <label for="name">Full Name</label>
            <input type="text" id="name" placeholder="Enter your full name" name="name ">
            <p class="error" id="name-error"></p>

            <label for="email">Email</label>
            <input type="email" id="email" placeholder="Enter your email" name="email">
            <p class="error" id="email-error"></p>

            <label for="age">Age</label>
            <input type="number" id="age" placeholder="Enter your age" name="age">
            <p class="error" id="age-error"></p>

            <label for="gender">Gender</label>
            <input type="text" id="gender" placeholder="Enter your gender" name="gender">
            <p class="error" id="gender-error"></p>

            <label for="relation">Relation with Patient</label>
            <input type="text" id="relation" placeholder="Enter your relation with patient" name="relation">
            <p class="error" id="relation-error"></p>

            <label for="patient-email">Patient Email</label>
            <input type="email" id="patient-email" placeholder="Enter patient's email" nane="p_mail">
            <p class="error" id="patient-email-error"></p>

            <input type="submit" value="Submit" 
            class="w-full bg-green-600 text-white font-semibold py-2 rounded-lg 
               hover:bg-green-700 transition-all duration-300 ease-in-out 
               focus:outline-none focus:ring-4 focus:ring-green-400 cursor-pointer">
        </form>
    </div>

    <script>
        document.getElementById("caretakerForm").addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent form submission
            
            // Getting values
            let name = document.getElementById("name").value.trim();
            let email = document.getElementById("email").value.trim();
            let age = document.getElementById("age").value.trim();
            let gender = document.getElementById("gender").value.trim();
            let relation = document.getElementById("relation").value.trim();
            let patientEmail = document.getElementById("patient-email").value.trim();

            // Error messages
            let nameError = document.getElementById("name-error");
            let emailError = document.getElementById("email-error");
            let ageError = document.getElementById("age-error");
            let genderError = document.getElementById("gender-error");
            let relationError = document.getElementById("relation-error");
            let patientEmailError = document.getElementById("patient-email-error");

            // Reset errors
            nameError.innerText = "";
            emailError.innerText = "";
            ageError.innerText = "";
            genderError.innerText = "";
            relationError.innerText = "";
            patientEmailError.innerText = "";

            let isValid = true;

            // Validation checks
            if (name === "") {
                nameError.innerText = "Full name is required!";
                isValid = false;
            }

            if (email === "" || !email.includes("@")) {
                emailError.innerText = "Enter a valid email!";
                isValid = false;
            }

            if (age === "" || isNaN(age) || age < 1 || age > 120) {
                ageError.innerText = "Enter a valid age (1-120)!";
                isValid = false;
            }

            if (gender === "") {
                genderError.innerText = "Gender is required!";
                isValid = false;
            }

            if (relation === "") {
                relationError.innerText = "Relation with patient is required!";
                isValid = false;
            }

            if (patientEmail === "" || !patientEmail.includes("@")) {
                patientEmailError.innerText = "Enter a valid patient email!";
                isValid = false;
            }

            // If all fields are valid, show success message
            if (isValid) {
                alert(Caretaker Registered Successfully!\n\nName: ${name}\nEmail: ${email}\nAge: ${age}\nGender: ${gender}\nRelation: ${relation}\nPatient Email: ${patientEmail});
                document.getElementById("caretakerForm").reset(); // Reset form after submission
            }
        });
    </script>
</body>
</html>