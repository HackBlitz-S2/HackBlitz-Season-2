<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Login</title>
    <style>
        /* Reset Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        /* Centering the form */
        body {
            background-color: #f5f8f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Form container */
        .container {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 350px;
            text-align: center;
        }

        /* Form title */
        h2 {
            font-size: 22px;
            font-weight: bold;
            color: #1a3b4c;
            margin-bottom: 5px;
        }

        /* Subtext */
        .subtext {
            font-size: 14px;
            color: #6b7b8c;
            margin-bottom: 20px;
        }

        /* Labels */
        label {
            font-size: 14px;
            font-weight: 600;
            display: block;
            text-align: left;
            margin: 10px 0 5px;
        }

        /* Input fields */
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #d1d5db;
            border-radius: 5px;
            font-size: 14px;
            background-color: #f8f9fa;
        }

        /* Submit button */
        button {
            width: 100%;
            background: #56c7c5;
            color: white;
            font-size: 16px;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 15px;
        }

        button:hover {
            background: #4ab0b0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Patient Login</h2>
        <p class="subtext">Please enter your information to continue</p>
        <form method="GET" action="patient_connect.php">
            <label for="full-name">Full Name</label>
            <input type="text" id="full-name" placeholder="Enter your full name" name="name">

            <label for="age">Age</label>
            <input type="number" id="age" placeholder="Enter your age" name="age">

            <label for="gender">Gender</label>
            <input type="text" id="gender" placeholder="Enter your gender" name="gender">

            <label for="disease">Disease</label>
            <input type="text" id="disease" placeholder="Enter your disease" name="disease">

            <button type="submit" name="submit" value="submit">Submit</button>
        </form>
    </div>
</body>
</html>