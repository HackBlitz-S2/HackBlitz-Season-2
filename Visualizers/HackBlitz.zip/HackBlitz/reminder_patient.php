<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedGuard - Patient Home</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #4CAF50;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            gap: 15px;
        }

        nav ul li {
            display: inline;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            padding: 8px 12px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        nav ul li a:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        main {
            padding: 20px;
        }

        section {
            margin-bottom: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 15px;
        }

        h2 {
            color: #4CAF50;
            margin-bottom: 10px;
        }

        .schedule-container {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .medication-card {
            background-color: #f1f1f1;
            border-radius: 6px;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .medication-card h3 {
            margin: 0;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #45a049;
        }

        .taken {
            background-color: #ccc !important;
            cursor: default;
        }

        .input-container {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-top: 15px;
        }

        input {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
        }

        footer {
            text-align: center;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">MedGuard</div>
        <nav>
            <ul>
                <li><a href="#schedule">Schedule</a></li>
                <li><a href="#reminders">Reminders</a></li>
                <li><a href="#notes">Doctor's Notes</a></li>
                <li><a href="#profile">Profile</a></li>
                <li><a href="#emergency">Emergency</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section id="schedule">
            <h2>Your Medication Schedule</h2>
            
            <div class="input-container">
                <input type="text" id="medicineName" placeholder="Enter Medicine Name">
                <input type="time" id="medicineTime">
                <button onclick="addMedicine()">Add Medicine</button>
            </div>

            <div class="schedule-container" id="medicineList">
                <div class="medication-card">
                    <h3>Paracetamol</h3>
                    <p>Time: 08:00 AM</p>
                    <button onclick="markAsTaken(this)">Mark as Taken</button>
                </div>
                <div class="medication-card">
                    <h3>Vitamin D</h3>
                    <p>Time: 12:00 PM</p>
                    <button onclick="markAsTaken(this)">Mark as Taken</button>
                </div>
            </div>
        </section>
    </main>

    <footer>
        &copy; 2025 MedGuard. All rights reserved.
    </footer>

    <script>
        function addMedicine() {
            const name = document.getElementById("medicineName").value;
            const time = document.getElementById("medicineTime").value;

            if (name === "" || time === "") {
                alert("Please enter both Medicine Name and Time!");
                return;
            }

            const medicineList = document.getElementById("medicineList");

            const medicineCard = document.createElement("div");
            medicineCard.classList.add("medication-card");

            medicineCard.innerHTML = `
                <h3>${name}</h3>
                <p>Time: ${time}</p>
                <button onclick="markAsTaken(this)">Mark as Taken</button>
            `;

            medicineList.appendChild(medicineCard);
            
            document.getElementById("medicineName").value = "";
            document.getElementById("medicineTime").value = "";
        }

        function markAsTaken(button) {
            button.innerText = "Taken";
            button.classList.add("taken");
            button.disabled = true;
        }
    </script>
</body>
</html>